Unable to parse built-ins
ERROR: 0:2798: 'redefinition of built-in function' : not supported with this profile: es
INTERNAL ERROR: Unable to parse built-ins

..
..
..

ERROR: C:\Users\devWin10\Desktop\seed2\driver_celshade_example\driver_celshade_example-master-ini-bk\build_forest_test36\compiled\Shaders\Project\GrassMaterial.frag.glsl:17: 'texture' : no matching overloaded function found
ERROR: C:\Users\devWin10\Desktop\seed2\driver_celshade_example\driver_celshade_example-master-ini-bk\build_forest_test36\compiled\Shaders\Project\GrassMaterial.frag.glsl:17: '' : compilation terminated
ERROR: 2 compilation errors.  No code generated.


ERROR: Linking fragment stage: Missing entry point: Each stage requires one entry point

SPIR-V is not generated for failed compile or link

Compiling shader 1 of 2 (GrassMaterial.frag.glsl) failed:
Shader compiler error.
(node:6348) UnhandledPromiseRejectionWarning: Shader compiler error.
(node:6348) UnhandledPromiseRejectionWarning: Unhandled promise rejection. This error originated either by throwing inside of an async function without a catch block, or by rejecting a promise which was not handled with .catch(). (rejection id: 2)
(node:6348) [DEP0018] DeprecationWarning: Unhandled promise rejections are deprecated. In the future, promise rejections that are not handled will terminate the Node.js process with a non-zero exit code.
Finished in 2.955s
ERROR: Build failed, check console