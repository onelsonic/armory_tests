#include "sources.c"

void frame() {
	kha_SystemImpl_frame();
}
