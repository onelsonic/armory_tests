// Auto-generated
let project = new Project('particuleswithshaderbug2_1_0_1');

project.addSources('Sources');
project.addLibrary("C:/armorylatestSDK/armory");
project.addLibrary("C:/armorylatestSDK/iron");
project.addParameter('-dce full');
project.addParameter('armory.trait.internal.UniformsManager');
project.addParameter("--macro keep('armory.trait.internal.UniformsManager')");
project.addShaders("build_particuleswithshaderbug2/compiled/Shaders/*.glsl", { noembed: false});
project.addAssets("build_particuleswithshaderbug2/compiled/Assets/**", { notinlist: true });
project.addAssets("build_particuleswithshaderbug2/compiled/Shaders/*.arm", { notinlist: true });
project.addAssets("Assets/ground.jpg", { notinlist: true });
project.addDefine('rp_renderer=Forward');
project.addDefine('rp_shadowmap');
project.addDefine('rp_shadowmap_cascade=1024');
project.addDefine('rp_shadowmap_cube=256');
project.addDefine('rp_background=Clear');
project.addDefine('arm_published');
project.addDefine('arm_soundcompress');
project.addDefine('arm_audio');
project.addDefine('arm_skin');
project.addDefine('arm_particles');
project.addDefine('arm_loadscreen');
project.addDefine('armory');
project.targetOptions.android_native.package = 'org.armory3d';
project.targetOptions.android_native.screenOrientation = 'landscape';
project.targetOptions.android_native.compileSdkVersion = '30';
project.targetOptions.android_native.minSdkVersion = '23';
project.targetOptions.android_native.targetSdkVersion = '26';


resolve(project);
