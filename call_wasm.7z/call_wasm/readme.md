http://armory3d.org/manual/#/code/wasm
