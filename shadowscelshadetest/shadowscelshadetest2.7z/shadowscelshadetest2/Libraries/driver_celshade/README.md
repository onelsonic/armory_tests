# driver_celshade
Celshade/toon rendering driver for Armory

Usage:
- `git clone https://github.com/armory3d/driver_celshade` (or [Download Zip](https://github.com/armory3d/driver_celshade/archive/master.zip)) into your `project_root/Libraries` folder
- Open .blend file and set `Properties - Render - Armory Render Path - Driver` to `Celshade`
